package application;

import entites.Produtos;
import java.util.Scanner;

public class Programa {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Produtos produto = new Produtos();

        System.out.println("Nome do produto: ");
        produto.nome = sc.nextLine();

        System.out.println("Preço: ");
        produto.preco = sc.nextDouble();

        System.out.println("Quantidade: ");
        produto.quantidade = sc.nextInt();

        //Imprimir
        System.out.println(produto);

    sc.close();
    }
}
