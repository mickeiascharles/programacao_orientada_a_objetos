package entites;

public class Produtos {
    public String nome;
    public double preco;
    public int quantidade;

    public double total(){
        return preco*quantidade;
    }

    public void addProdutos(int quantidade){
        this.quantidade += quantidade;
    }

    public void removeProdutos (int quantidade){
        this.quantidade -= quantidade;
    }
    public String toString(){
    return  "Produto: "
            +nome
            +"\n Preço: R$ "
            + String.format("%.2f",preco)
            +"\n Quantidade: "
            +quantidade
            +"\n Total: $"
            + String.format("%.2f", total());
    }
}