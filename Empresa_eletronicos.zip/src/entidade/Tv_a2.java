package entidade;

public class Tv_a2 {
    public String modelo = "A2_Samsung";
    public String cor = "White";
    public Float tamanho = 50f;
    public boolean energia;

    public void ligar(){
        this.energia = true;
    }
    public void desligar(){
        this.energia = false;
    }
    public String toString() {
        return "Modelo: " + modelo
                + "\nCor: " + cor
                + "\nPolegadas: " + tamanho
                + "\nLigado: " + energia
                + "\n=================";
    }
}
