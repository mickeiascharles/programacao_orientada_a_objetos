//Arquivo main:
package aplicacao;

//Importando os arquivos de outro package mas do mesmo projeto:
import entidade.Tv_a1;
import entidade.Tv_a2;
import entidade.Tv_c137;

public class Programa {
    public static void main(String[] args) { //Isso faz com que o arquivo se torne principal main, assim gera o run
        Tv_a1 tv1 = new Tv_a1();
        Tv_c137 tv2 = new Tv_c137();
        Tv_a2 tv3 = new Tv_a2();

        tv1.desligar();
        System.out.println(tv1);

        tv2.ligar();
        System.out.println(tv2);

        tv3.ligar();
        System.out.println(tv3);

    }
}
